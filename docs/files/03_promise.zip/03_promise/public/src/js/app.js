/*
    parsed --> install --> activate --> idle --> terminated (redundant)

    idle <--> fetch /message 
*/
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
        .then(reg => console.log(reg))
        .catch(err => console.log(err));
}

new Promise((resolve, reject) => {
        let cond = true;

        if (cond) {
            setTimeout(() => resolve("https://jsonplaceholder.typicode.com/posts"), 1000);
        } else {
            setTimeout(() => reject(new Error("das ist schlecht")), 1000);
        }
    })
    .then(
        url => {
            return fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    title: 'FIW!',
                    user: 3
                })
            });
        }
    )
    .then(
        response => {
            console.log(response);
            return response.json();
        }
    )
    .then(
        obj => {
            console.log(obj);
            document.getElementById('output').textContent = obj.title;
        }
    )
    .catch(
        error => console.log(error)
    );